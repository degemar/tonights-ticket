window.FRIDAY_PLAN_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  appSlug: "tonights-ticket"
};
