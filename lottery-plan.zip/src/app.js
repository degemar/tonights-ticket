(function () {
  var store = window.FridayPlanStore;
  var state = {
    plans: [],
    filters: {
      time: "any",
      kids: "with-kids",
      energy: "any"
    },
    selectedPlanId: null,
    favorites: store.getFavorites(),
    history: store.getHistory()
  };

  var els = {
    syncStatus: document.getElementById("syncStatus"),
    drawContext: document.getElementById("drawContext"),
    drawTitle: document.getElementById("drawTitle"),
    numberGrid: document.getElementById("numberGrid"),
    winnerBand: document.getElementById("winnerBand"),
    randomButton: document.getElementById("randomButton"),
    favoritesList: document.getElementById("favoritesList"),
    historyList: document.getElementById("historyList"),
    clearFavoritesButton: document.getElementById("clearFavoritesButton"),
    clearHistoryButton: document.getElementById("clearHistoryButton")
  };

  function text(value) {
    return String(value == null ? "" : value);
  }

  function matchesFilters(plan) {
    var filters = state.filters;
    return (filters.time === "any" || plan.time === filters.time) &&
      plan.kids === filters.kids &&
      (filters.energy === "any" || plan.energy === filters.energy);
  }

  function getVisiblePlans() {
    return state.plans.filter(matchesFilters);
  }

  function findPlanById(planId) {
    return state.plans.find(function (plan) {
      return plan.id === planId;
    });
  }

  function formatKidMode(mode) {
    if (mode === "after-bed") return "without kids";
    if (mode === "with-kids") return "with kids";
    return mode;
  }

  function currentModeLabel() {
    return state.filters.kids === "after-bed" ? "Without kids" : "With kids";
  }

  function renderDrawHeading() {
    var visibleCount = getVisiblePlans().length;
    var modeLabel = currentModeLabel();
    els.drawContext.textContent = modeLabel + " lottery";
    els.drawTitle.textContent = modeLabel === "Without kids" ? "Date tickets" : "Family tickets";
    els.randomButton.disabled = visibleCount === 0;
    els.randomButton.title = visibleCount === 0 ? "No tickets match these filters" : "Draw a random ticket";
    els.randomButton.setAttribute("aria-label", els.randomButton.title);
  }

  function renderNumbers() {
    els.numberGrid.innerHTML = "";

    var visiblePlans = getVisiblePlans();

    if (visiblePlans.length === 0) {
      els.numberGrid.innerHTML = '<p class="number-empty">No tickets match this combination. Loosen time or energy.</p>';
      return;
    }

    visiblePlans.forEach(function (plan) {
      var button = document.createElement("button");
      button.className = "ticket-button";
      button.type = "button";
      button.textContent = text(plan.number);
      button.setAttribute("aria-label", "Choose plan number " + plan.number);

      if (state.selectedPlanId === plan.id) {
        button.classList.add("selected");
      }

      button.addEventListener("click", function () {
        choosePlan(plan);
      });

      els.numberGrid.appendChild(button);
    });
  }

  function renderWinner() {
    var plan = findPlanById(state.selectedPlanId);

    if (!plan) {
      els.winnerBand.innerHTML = [
        '<div class="empty-winner">',
        '<p class="eyebrow">Tonight\'s plan</p>',
        "<h2>The ticket is waiting.</h2>",
        "<p>The first ticket gets all the ceremony.</p>",
        "</div>"
      ].join("");
      return;
    }

    var isFavorite = state.favorites.indexOf(plan.id) !== -1;
    var rules = plan.rules.map(function (rule) {
      return "<li>" + escapeHtml(rule) + "</li>";
    }).join("");

    els.winnerBand.innerHTML = [
      '<article class="winner-card">',
      '<div class="winner-top">',
      '<div class="winning-number">' + escapeHtml(plan.number) + "</div>",
      "<div>",
      '<p class="eyebrow">Winning plan</p>',
      '<h2 class="winner-title">' + escapeHtml(plan.title) + "</h2>",
      '<div class="tag-row">',
      '<span class="tag">' + escapeHtml(plan.duration) + "</span>",
      '<span class="tag teal">' + escapeHtml(formatKidMode(plan.kids)) + "</span>",
      '<span class="tag blue">' + escapeHtml(plan.energy) + " energy</span>",
      '<span class="tag leaf">' + escapeHtml(plan.vibe) + "</span>",
      "</div>",
      "</div>",
      "</div>",
      '<div class="winner-body">',
      '<div class="detail-grid">',
      detailBox("Use", plan.materials),
      detailBox("Setup", plan.setup),
      '<div class="detail-box"><h3>Rules</h3><ul>' + rules + "</ul></div>",
      detailBox("Tiny Twist", plan.twist),
      detailBox("Why This Wins", plan.grownupWin),
      "</div>",
      '<div class="winner-actions">',
      '<button class="primary-action" id="drawAgainButton" type="button">Draw again</button>',
      '<button class="primary-action ' + (isFavorite ? "favorite-on" : "") + '" id="favoriteButton" type="button">' + (isFavorite ? "Favorited" : "Favorite") + "</button>",
      "</div>",
      "</div>",
      "</article>"
    ].join("");

    document.getElementById("drawAgainButton").addEventListener("click", drawRandomPlan);
    document.getElementById("favoriteButton").addEventListener("click", function () {
      toggleFavorite(plan.id);
    });
  }

  function detailBox(label, value) {
    return '<div class="detail-box"><h3>' + escapeHtml(label) + "</h3><p>" + escapeHtml(value) + "</p></div>";
  }

  function renderMiniLists() {
    renderFavorites();
    renderHistory();
  }

  function renderFavorites() {
    var favoritePlans = state.favorites
      .map(findPlanById)
      .filter(Boolean);

    if (favoritePlans.length === 0) {
      els.favoritesList.innerHTML = '<p class="empty-mini">No favorites yet. Save the plans that make her laugh.</p>';
      return;
    }

    els.favoritesList.innerHTML = favoritePlans.map(function (plan) {
      return miniItem(plan.number, plan.title, plan.duration + " - " + formatKidMode(plan.kids), plan.id);
    }).join("");

    bindMiniItems(els.favoritesList);
  }

  function renderHistory() {
    if (state.history.length === 0) {
      els.historyList.innerHTML = '<p class="empty-mini">No recent wins yet. The first draw gets all the ceremony.</p>';
      return;
    }

    els.historyList.innerHTML = state.history.slice(0, 5).map(function (entry) {
      var date = new Date(entry.drawnAt);
      var when = isNaN(date.getTime()) ? "recently" : date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
      return miniItem(entry.number, entry.title, when, entry.planId);
    }).join("");

    bindMiniItems(els.historyList);
  }

  function miniItem(number, title, meta, planId) {
    return [
      '<button class="mini-item" type="button" data-plan-id="' + escapeHtml(planId) + '">',
      '<span class="mini-num">' + escapeHtml(number) + "</span>",
      "<span>",
      '<span class="mini-title">' + escapeHtml(title) + "</span>",
      '<span class="mini-meta">' + escapeHtml(meta) + "</span>",
      "</span>",
      "</button>"
    ].join("");
  }

  function bindMiniItems(container) {
    Array.prototype.forEach.call(container.querySelectorAll("[data-plan-id]"), function (item) {
      item.addEventListener("click", function () {
        var plan = findPlanById(item.getAttribute("data-plan-id"));
        if (plan) {
          state.filters.kids = plan.kids;
          syncFilterButtons("kids");
          choosePlan(plan, { skipRecord: true });
        }
      });
    });
  }

  function choosePlan(plan, options) {
    state.selectedPlanId = plan.id;
    render();

    if (!options || !options.skipRecord) {
      store.recordDraw(plan).then(function () {
        state.history = store.getHistory();
        renderMiniLists();
      });
    }

    els.winnerBand.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function drawRandomPlan() {
    var visiblePlans = getVisiblePlans();
    if (visiblePlans.length === 0) {
      return;
    }

    var pool = visiblePlans;
    var recentIds = state.history.slice(0, 3).map(function (entry) {
      return entry.planId;
    });
    var lessRecentPool = pool.filter(function (plan) {
      return recentIds.indexOf(plan.id) === -1;
    });
    var finalPool = lessRecentPool.length ? lessRecentPool : pool;
    var plan = finalPool[Math.floor(Math.random() * finalPool.length)];

    if (plan) {
      choosePlan(plan);
    }
  }

  function toggleFavorite(planId) {
    var index = state.favorites.indexOf(planId);

    if (index === -1) {
      state.favorites.unshift(planId);
    } else {
      state.favorites.splice(index, 1);
    }

    store.saveFavorites(state.favorites);
    render();
  }

  function setupFilters() {
    Array.prototype.forEach.call(document.querySelectorAll("[data-filter]"), function (button) {
      button.addEventListener("click", function () {
        var filterName = button.getAttribute("data-filter");
        var value = button.getAttribute("data-value");
        state.filters[filterName] = value;
        clearWinnerIfHidden();
        syncFilterButtons(filterName);
        render();
      });
    });
  }

  function syncFilterButtons(filterName) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-filter="' + filterName + '"]'), function (peer) {
      peer.classList.toggle("active", peer.getAttribute("data-value") === state.filters[filterName]);
    });
  }

  function clearWinnerIfHidden() {
    var selected = findPlanById(state.selectedPlanId);
    if (selected && !matchesFilters(selected)) {
      state.selectedPlanId = null;
    }
  }

  function escapeHtml(value) {
    return text(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function render() {
    renderDrawHeading();
    renderNumbers();
    renderWinner();
    renderMiniLists();
  }

  function init() {
    els.syncStatus.textContent = store.hasSupabase
      ? "Supabase connected"
      : "Local mode ready";

    setupFilters();

    els.randomButton.addEventListener("click", drawRandomPlan);
    els.clearFavoritesButton.addEventListener("click", function () {
      state.favorites = [];
      store.saveFavorites(state.favorites);
      render();
    });
    els.clearHistoryButton.addEventListener("click", function () {
      state.history = [];
      store.saveHistory(state.history);
      render();
    });

    store.loadPlans(window.FRIDAY_PLAN_DEFAULTS || []).then(function (plans) {
      state.plans = plans;
      render();
    });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
