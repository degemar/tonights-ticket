(function () {
  var STORAGE_KEYS = {
    history: "fridayPlanLottery.history",
    favorites: "fridayPlanLottery.favorites"
  };

  function readJson(key, fallback) {
    try {
      var raw = window.localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function writeJson(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      // Local mode still works without persistence if the browser blocks storage.
    }
  }

  function createSupabaseClient() {
    var config = window.FRIDAY_PLAN_CONFIG || {};
    var hasConfig = Boolean(config.supabaseUrl && config.supabaseAnonKey);
    var hasLibrary = Boolean(window.supabase && window.supabase.createClient);

    if (!hasConfig || !hasLibrary) {
      return null;
    }

    return window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);
  }

  var client = createSupabaseClient();

  window.FridayPlanStore = {
    hasSupabase: Boolean(client),

    getHistory: function () {
      return readJson(STORAGE_KEYS.history, []);
    },

    saveHistory: function (history) {
      writeJson(STORAGE_KEYS.history, history.slice(0, 12));
    },

    getFavorites: function () {
      return readJson(STORAGE_KEYS.favorites, []);
    },

    saveFavorites: function (favorites) {
      writeJson(STORAGE_KEYS.favorites, favorites);
    },

    loadPlans: function (fallbackPlans) {
      var config = window.FRIDAY_PLAN_CONFIG || {};

      if (!client) {
        return Promise.resolve(fallbackPlans);
      }

      return client
        .from("plans")
        .select("*")
        .eq("app_slug", config.appSlug || "tonights-ticket")
        .eq("is_active", true)
        .order("number", { ascending: true })
        .then(function (result) {
          if (result.error || !result.data || result.data.length === 0) {
            return fallbackPlans;
          }

          return result.data.map(function (row) {
            return {
              id: row.id,
              number: row.number,
              title: row.title,
              duration: row.duration,
              time: row.time_bucket,
              kids: row.kid_mode,
              energy: row.energy_level,
              vibe: row.vibe,
              materials: row.materials,
              setup: row.setup,
              rules: row.rules || [],
              twist: row.twist,
              grownupWin: row.grownup_win
            };
          });
        })
        .catch(function () {
          return fallbackPlans;
        });
    },

    recordDraw: function (plan) {
      var history = this.getHistory();
      var entry = {
        planId: plan.id,
        number: plan.number,
        title: plan.title,
        drawnAt: new Date().toISOString()
      };

      history.unshift(entry);
      this.saveHistory(history);

      if (!client) {
        return Promise.resolve(entry);
      }

      return client
        .from("draws")
        .insert({
          app_slug: (window.FRIDAY_PLAN_CONFIG || {}).appSlug || "tonights-ticket",
          plan_id: plan.id,
          plan_number: plan.number,
          plan_title: plan.title,
          user_agent: window.navigator.userAgent
        })
        .then(function () {
          return entry;
        })
        .catch(function () {
          return entry;
        });
    }
  };
})();
